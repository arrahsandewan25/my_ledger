import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  LayoutGrid, ArrowLeftRight, Wallet, PieChart as PieIcon, Target, TrendingUp,
  BarChart3, FileText, LineChart as LineIcon, Repeat, Receipt, Calendar as CalendarIcon,
  Settings as SettingsIcon, User, Search, Command, Plus, ChevronDown, ChevronRight,
  ArrowUpRight, ArrowDownRight, Sun, Moon, Cloud, X, Bell, Menu, Filter, SlidersHorizontal,
  ShoppingCart, Utensils, Car, ShoppingBag, Film, Zap, Briefcase, HeartPulse, Plane,
  Sparkles, CheckCircle2, AlertTriangle, Clock, ChevronLeft, Coffee, CreditCard,
  Building2, Landmark, Bitcoin, Banknote, TrendingDown, Star, MoreHorizontal, Tag,
  Home as HomeIcon, Dumbbell, Music, Smartphone
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell,
} from "recharts";

/* ============================== THEME TOKENS ============================== */
const THEMES = {
  dark: {
    bg: "#0A0B12", surface: "#12141F", surface2: "#171A28", surface3: "#1D2032",
    border: "rgba(255,255,255,0.08)", borderStrong: "rgba(255,255,255,0.14)",
    text: "#F1F2F6", textMuted: "#8A8FA3", textFaint: "#5B5F72",
    accent: "#6366F1", accent2: "#8B5CF6", accentSoft: "rgba(99,102,241,0.16)",
    glass: "rgba(255,255,255,0.045)", glassStrong: "rgba(255,255,255,0.07)",
    emerald: "#34D399", rose: "#FB7185", amber: "#FBBF24", slate: "#6B7280",
    heroFrom: "#4F46E5", heroVia: "#6D28D9", heroTo: "#312E81",
    shadow: "0 20px 60px -20px rgba(0,0,0,0.6)",
  },
  light: {
    bg: "#F6F7FB", surface: "#FFFFFF", surface2: "#FBFBFE", surface3: "#F1F2F8",
    border: "rgba(15,17,30,0.08)", borderStrong: "rgba(15,17,30,0.14)",
    text: "#14161F", textMuted: "#6B6F82", textFaint: "#9A9DAD",
    accent: "#5B5FEF", accent2: "#7C3AED", accentSoft: "rgba(91,95,239,0.10)",
    glass: "rgba(255,255,255,0.6)", glassStrong: "rgba(255,255,255,0.8)",
    emerald: "#0EA26F", rose: "#E11D48", amber: "#D97706", slate: "#94A3B8",
    heroFrom: "#5B5FEF", heroVia: "#7C6FF0", heroTo: "#4338CA",
    shadow: "0 20px 50px -24px rgba(30,32,60,0.22)",
  },
  neutral: {
    bg: "#F1EEE7", surface: "#FAF8F3", surface2: "#F5F2EB", surface3: "#EDE9E0",
    border: "rgba(50,45,35,0.09)", borderStrong: "rgba(50,45,35,0.16)",
    text: "#2A2620", textMuted: "#7A7364", textFaint: "#A69F8D",
    accent: "#6B5FCF", accent2: "#B08968", accentSoft: "rgba(107,95,207,0.10)",
    glass: "rgba(255,253,248,0.6)", glassStrong: "rgba(255,253,248,0.85)",
    emerald: "#3E8E6A", rose: "#B7554A", amber: "#B4863A", slate: "#A39B8B",
    heroFrom: "#6B5FCF", heroVia: "#8B7BBF", heroTo: "#4E4587",
    shadow: "0 20px 50px -24px rgba(50,40,20,0.18)",
  },
};

const fmt = (n, opts = {}) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2, ...opts }).format(n);
const fmtCompact = (n) => new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(n);
const fmtDate = (d) => new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric" });
const cx = (...a) => a.filter(Boolean).join(" ");

/* ============================== SAMPLE DATA ============================== */
const CATEGORIES = {
  groceries:   { label: "Groceries",   color: "emerald", icon: ShoppingCart },
  dining:      { label: "Dining",      color: "amber",   icon: Utensils },
  transport:   { label: "Transport",   color: "accent",  icon: Car },
  shopping:    { label: "Shopping",    color: "rose",    icon: ShoppingBag },
  entertainment:{ label: "Entertainment", color: "accent2", icon: Film },
  utilities:   { label: "Bills & Utilities", color: "slate", icon: Zap },
  income:      { label: "Income",      color: "emerald", icon: Briefcase },
  transfer:    { label: "Transfer",    color: "slate",   icon: ArrowLeftRight },
  health:      { label: "Health",      color: "rose",    icon: HeartPulse },
  subscriptions:{ label: "Subscriptions", color: "accent2", icon: Repeat },
  travel:      { label: "Travel",      color: "amber",   icon: Plane },
  home:        { label: "Home",        color: "accent",  icon: HomeIcon },
};

const INITIAL_ACCOUNTS = [
  { id: "chk", name: "Everyday Checking", type: "Checking", bank: "Meridian Bank", balance: 12480.32, trend: 3.2, icon: Landmark, last4: "4821" },
  { id: "sav", name: "High-Yield Savings", type: "Savings", bank: "Meridian Bank", balance: 34200.0, trend: 1.8, icon: Wallet, last4: "9013" },
  { id: "cc", name: "Horizon Rewards", type: "Credit Card", bank: "Horizon Card Co.", balance: -1240.55, trend: -8.4, icon: CreditCard, last4: "2277" },
  { id: "inv", name: "Brokerage", type: "Investment", bank: "Alpine Invest", balance: 58930.12, trend: 5.6, icon: Building2, last4: "5510" },
  { id: "cry", name: "Crypto Wallet", type: "Crypto", bank: "Self-custody", balance: 4210.88, trend: 12.1, icon: Bitcoin, last4: "0x9F" },
  { id: "csh", name: "Cash", type: "Cash", bank: "On hand", balance: 320.0, trend: 0, icon: Banknote, last4: "" },
];

const MERCHANTS = {
  groceries: ["Whole Foods", "Trader Joe's", "Local Market"],
  dining: ["Blue Bottle Coffee", "Ramen House", "The Corner Bistro"],
  transport: ["Uber", "Shell Gas", "City Metro"],
  shopping: ["Amazon", "Uniqlo", "West Elm"],
  entertainment: ["AMC Theatres", "Steam", "Spotify Concerts"],
  utilities: ["Pacific Power", "CityWater Co.", "Comcast"],
  income: ["Acme Corp Payroll", "Freelance Client", "Dividend Payout"],
  transfer: ["Savings Transfer", "To Brokerage"],
  health: ["CVS Pharmacy", "Dr. Chen Clinic", "Equinox Gym"],
  subscriptions: ["Netflix", "Spotify", "iCloud+", "Notion"],
  travel: ["Delta Airlines", "Airbnb", "Marriott"],
  home: ["Home Depot", "IKEA"],
};

function seedTransactions() {
  const cats = Object.keys(CATEGORIES);
  const out = [];
  let id = 1;
  for (let i = 0; i < 34; i++) {
    const cat = cats[Math.floor(Math.random() * cats.length)];
    const isIncome = cat === "income";
    const isTransfer = cat === "transfer";
    const merchList = MERCHANTS[cat];
    const merchant = merchList[Math.floor(Math.random() * merchList.length)];
    const amount = isIncome
      ? [3200, 850, 62.4][Math.floor(Math.random() * 3)]
      : isTransfer
      ? 500
      : +(Math.random() * 180 + 6).toFixed(2);
    const day = Math.floor(Math.random() * 27) + 1;
    out.push({
      id: id++,
      merchant,
      category: cat,
      amount: isIncome ? amount : isTransfer ? amount : -amount,
      date: new Date(2026, 6, day).toISOString(),
      account: INITIAL_ACCOUNTS[Math.floor(Math.random() * 3)].name,
      type: isIncome ? "income" : isTransfer ? "transfer" : "expense",
      recurring: ["subscriptions", "utilities"].includes(cat) || Math.random() > 0.85,
      notes: "",
      tags: Math.random() > 0.7 ? ["work"] : Math.random() > 0.5 ? ["personal"] : [],
    });
  }
  return out.sort((a, b) => new Date(b.date) - new Date(a.date));
}
const INITIAL_TRANSACTIONS = seedTransactions();
let nextTxId = 1000;
let nextGoalId = 100;

const MONTHLY = [
  { m: "Feb", income: 5200, expense: 3800 },
  { m: "Mar", income: 5200, expense: 4100 },
  { m: "Apr", income: 5600, expense: 3600 },
  { m: "May", income: 5200, expense: 4400 },
  { m: "Jun", income: 6100, expense: 3950 },
  { m: "Jul", income: 5200, expense: 3540 },
];

const CASHFLOW_DAILY = Array.from({ length: 30 }, (_, i) => {
  const base = 46000 + i * 180;
  const wiggle = Math.sin(i / 3) * 900 + (Math.random() - 0.5) * 400;
  return { d: `${i + 1}`, balance: Math.round(base + wiggle), forecast: i > 22 ? Math.round(base + wiggle + (i - 22) * 260) : null };
});

const BUDGETS = [
  { id: 1, category: "groceries", limit: 600, spent: 452 },
  { id: 2, category: "dining", limit: 300, spent: 274 },
  { id: 3, category: "transport", limit: 200, spent: 138 },
  { id: 4, category: "entertainment", limit: 150, spent: 168 },
  { id: 5, category: "shopping", limit: 400, spent: 212 },
  { id: 6, category: "subscriptions", limit: 80, spent: 62 },
];

const INITIAL_GOALS = [
  { id: 1, name: "Emergency Fund", icon: Landmark, target: 15000, current: 9800, due: "2026-12-01", color: "accent" },
  { id: 2, name: "Vacation — Kyoto", icon: Plane, target: 4000, current: 2350, due: "2026-10-15", color: "amber" },
  { id: 3, name: "New Laptop", icon: Star, target: 2500, current: 2500, due: "2026-07-01", color: "emerald" },
  { id: 4, name: "Car Down Payment", icon: Car, target: 12000, current: 3100, due: "2027-03-01", color: "accent2" },
];

const SUBSCRIPTIONS = [
  { id: 1, name: "Netflix", icon: Film, price: 15.49, next: "2026-07-24", color: "rose" },
  { id: 2, name: "Spotify", icon: Music, price: 10.99, next: "2026-07-26", color: "emerald" },
  { id: 3, name: "iCloud+", icon: Cloud, price: 2.99, next: "2026-07-29", color: "accent" },
  { id: 4, name: "Equinox Gym", icon: Dumbbell, price: 39.99, next: "2026-08-01", color: "amber" },
  { id: 5, name: "Notion Plus", icon: FileText, price: 8.0, next: "2026-08-03", color: "accent2" },
  { id: 6, name: "Adobe CC", icon: Smartphone, price: 54.99, next: "2026-08-05", color: "rose" },
];

const INITIAL_BILLS = [
  { id: 1, name: "Rent", amount: 1850, due: "2026-08-01", autopay: false, status: "upcoming" },
  { id: 2, name: "Electric — Pacific Power", amount: 95.2, due: "2026-07-25", autopay: true, status: "upcoming" },
  { id: 3, name: "Internet — Comcast", amount: 60, due: "2026-07-28", autopay: true, status: "upcoming" },
  { id: 4, name: "Car Insurance", amount: 110, due: "2026-08-03", autopay: true, status: "upcoming" },
  { id: 5, name: "Phone — Verizon", amount: 75, due: "2026-07-14", autopay: true, status: "paid" },
];

const INSIGHTS = [
  { icon: TrendingDown, tone: "emerald", text: "You spent 12% less on Dining this month compared to June." },
  { icon: AlertTriangle, tone: "amber", text: "You exceeded your Entertainment budget by $18 this month." },
  { icon: Sparkles, tone: "accent", text: "Your savings rate improved to 31% — best in 6 months." },
];

const NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutGrid },
  { id: "transactions", label: "Transactions", icon: ArrowLeftRight },
  { id: "accounts", label: "Accounts", icon: Wallet },
  { id: "budgets", label: "Budgets", icon: PieIcon },
  { id: "goals", label: "Goals", icon: Target },
  { id: "cashflow", label: "Cash Flow", icon: LineIcon },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "subscriptions", label: "Subscriptions", icon: Repeat },
  { id: "bills", label: "Bills", icon: Receipt },
  { id: "investments", label: "Investments", icon: TrendingUp },
  { id: "reports", label: "Reports", icon: FileText },
  { id: "calendar", label: "Calendar", icon: CalendarIcon },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];

const GOAL_ICON_OPTIONS = [
  { key: "target", icon: Target }, { key: "landmark", icon: Landmark }, { key: "plane", icon: Plane },
  { key: "car", icon: Car }, { key: "home", icon: HomeIcon }, { key: "star", icon: Star },
];
const GOAL_COLOR_OPTIONS = ["accent", "accent2", "emerald", "amber", "rose"];

/* ============================== SMALL UI PRIMITIVES ============================== */

function useCountUp(value, duration = 900) {
  const [display, setDisplay] = useState(0);
  const raf = useRef();
  const start = useRef();
  useEffect(() => {
    start.current = null;
    const from = 0;
    const to = value;
    function step(ts) {
      if (!start.current) start.current = ts;
      const p = Math.min(1, (ts - start.current) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (to - from) * eased);
      if (p < 1) raf.current = requestAnimationFrame(step);
    }
    raf.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return display;
}

function GlassCard({ children, className = "", style = {}, hover = true, as: As = "div", ...rest }) {
  return (
    <As
      className={cx(
        "relative rounded-[20px] border backdrop-blur-xl transition-all duration-300",
        hover && "hover:-translate-y-[2px]",
        className
      )}
      style={{
        background: "var(--glass)",
        borderColor: "var(--border)",
        boxShadow: "var(--card-shadow)",
        ...style,
      }}
      {...rest}
    >
      {children}
    </As>
  );
}

function Pill({ children, tone = "slate", className = "" }) {
  return (
    <span
      className={cx("inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-medium", className)}
      style={{ background: `color-mix(in srgb, var(--${tone}) 16%, transparent)`, color: `var(--${tone})` }}
    >
      {children}
    </span>
  );
}

function CategoryIcon({ cat, size = "md" }) {
  const meta = CATEGORIES[cat] || CATEGORIES.shopping;
  const Icon = meta.icon;
  const dims = size === "sm" ? "w-8 h-8" : size === "lg" ? "w-12 h-12" : "w-9 h-9";
  return (
    <div
      className={cx(dims, "rounded-full grid place-items-center shrink-0")}
      style={{ background: `color-mix(in srgb, var(--${meta.color}) 18%, transparent)` }}
    >
      <Icon size={size === "lg" ? 20 : 16} style={{ color: `var(--${meta.color})` }} strokeWidth={2} />
    </div>
  );
}

function ProgressRing({ percent, size = 84, stroke = 8, color = "var(--accent)", track = "var(--surface3)", children }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const [animated, setAnimated] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setAnimated(Math.min(percent, 999)), 80);
    return () => clearTimeout(t);
  }, [percent]);
  const clamped = Math.min(animated, 100);
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke={track} strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={percent > 100 ? "var(--rose)" : color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (clamped / 100) * c}
          style={{ transition: "stroke-dashoffset 1s cubic-bezier(.22,1,.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

function SegmentedControl({ options, value, onChange }) {
  return (
    <div className="inline-flex rounded-full p-1 gap-0.5" style={{ background: "var(--surface3)" }}>
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className="relative rounded-full px-3 py-1.5 text-[12.5px] font-medium transition-colors duration-200"
          style={{
            background: value === o.value ? "var(--surface)" : "transparent",
            color: value === o.value ? "var(--text)" : "var(--textMuted)",
            boxShadow: value === o.value ? "0 1px 6px rgba(0,0,0,0.08)" : "none",
          }}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function SectionHeader({ eyebrow, title, action }) {
  return (
    <div className="flex items-end justify-between mb-4">
      <div>
        {eyebrow && (
          <div className="text-[11px] font-semibold tracking-[0.12em] uppercase mb-1" style={{ color: "var(--textFaint)" }}>
            {eyebrow}
          </div>
        )}
        <h2 className="text-[17px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>{title}</h2>
      </div>
      {action}
    </div>
  );
}

function EmptyState({ icon: Icon = Sparkles, title, subtitle }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-6">
      <div className="w-14 h-14 rounded-2xl grid place-items-center mb-4" style={{ background: "var(--accentSoft)" }}>
        <Icon size={22} style={{ color: "var(--accent)" }} />
      </div>
      <div className="font-semibold text-[15px] mb-1" style={{ color: "var(--text)" }}>{title}</div>
      <div className="text-[13px] max-w-xs" style={{ color: "var(--textMuted)" }}>{subtitle}</div>
    </div>
  );
}

/* ============================== CHART TOOLTIP ============================== */
function ChartTooltip({ active, payload, label, currency = true }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-xl px-3 py-2 border text-[12px]" style={{ background: "var(--surface)", borderColor: "var(--border)", boxShadow: "var(--card-shadow)" }}>
      <div className="font-medium mb-1" style={{ color: "var(--textMuted)" }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-1.5" style={{ color: p.color }}>
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: p.color }} />
          <span className="font-semibold tabular-nums">{currency ? fmt(p.value) : p.value}</span>
        </div>
      ))}
    </div>
  );
}

/* ============================== DASHBOARD ============================== */
function HeroBalanceCard({ theme, accounts, onAction }) {
  const netWorth = accounts.reduce((s, a) => s + a.balance, 0);
  const displayed = useCountUp(netWorth, 1200);
  const income = 6100, expense = 3540, savings = income - expense;
  return (
    <div
      className="relative overflow-hidden rounded-[28px] p-7 sm:p-9 text-white hero-shine"
      style={{
        background: `linear-gradient(135deg, ${THEMES[theme].heroFrom}, ${THEMES[theme].heroVia} 55%, ${THEMES[theme].heroTo})`,
        boxShadow: "0 30px 70px -24px rgba(76,60,220,0.45)",
      }}
    >
      <div className="hero-orb hero-orb-a" />
      <div className="hero-orb hero-orb-b" />
      <div className="relative z-10 flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
        <div>
          <div className="flex items-center gap-2 text-[12px] font-medium tracking-wide text-white/70 mb-3 uppercase">
            <Sparkles size={13} /> Net Worth
          </div>
          <div className="text-[44px] sm:text-[56px] font-semibold tracking-tight tabular-nums leading-none">
            {fmt(displayed, { maximumFractionDigits: 0 })}
          </div>
          <div className="flex flex-wrap items-center gap-3 mt-4">
            <span className="inline-flex items-center gap-1 text-[13px] font-medium bg-white/15 rounded-full px-2.5 py-1">
              <ArrowUpRight size={13} /> +2.4% today
            </span>
            <span className="inline-flex items-center gap-1 text-[13px] font-medium bg-white/15 rounded-full px-2.5 py-1">
              <ArrowUpRight size={13} /> +8.1% this month
            </span>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-5 sm:gap-8 w-full lg:w-auto">
          {[
            ["Income", income, ArrowUpRight],
            ["Expenses", expense, ArrowDownRight],
            ["Saved", savings, Sparkles],
          ].map(([label, val, Icon]) => (
            <div key={label}>
              <div className="flex items-center gap-1 text-[11.5px] text-white/65 mb-1"><Icon size={12} />{label}</div>
              <div className="text-[19px] sm:text-[21px] font-semibold tabular-nums">{fmt(val, { maximumFractionDigits: 0 })}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="relative z-10 flex flex-wrap gap-2.5 mt-8">
        {[
          { label: "Add Transaction", action: "transaction" },
          { label: "Transfer", action: "transfer" },
          { label: "Pay a Bill", action: "bill" },
          { label: "New Goal", action: "goal" },
        ].map((a) => (
          <button
            key={a.action}
            onClick={() => onAction(a.action)}
            className="text-[12.5px] font-medium bg-white/12 hover:bg-white/20 active:scale-[0.97] border border-white/15 rounded-full px-3.5 py-2 transition-all duration-200 flex items-center gap-1.5"
          >
            <Plus size={13} /> {a.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function IncomeExpenseChart() {
  return (
    <GlassCard className="p-5 sm:p-6">
      <SectionHeader eyebrow="Overview" title="Income vs Expense" />
      <div className="h-56">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={MONTHLY} barGap={6} margin={{ left: -18 }}>
            <CartesianGrid vertical={false} stroke="var(--border)" />
            <XAxis dataKey="m" tickLine={false} axisLine={false} tick={{ fill: "var(--textMuted)", fontSize: 12 }} />
            <YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--textMuted)", fontSize: 11 }} tickFormatter={fmtCompact} width={40} />
            <Tooltip content={<ChartTooltip />} cursor={{ fill: "var(--surface3)" }} />
            <Bar dataKey="income" radius={[6, 6, 0, 0]} fill="var(--emerald)" maxBarSize={16} animationDuration={900} />
            <Bar dataKey="expense" radius={[6, 6, 0, 0]} fill="var(--rose)" maxBarSize={16} animationDuration={900} animationBegin={120} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="flex items-center gap-4 mt-1 text-[12px]" style={{ color: "var(--textMuted)" }}>
        <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: "var(--emerald)" }} />Income</span>
        <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: "var(--rose)" }} />Expense</span>
      </div>
    </GlassCard>
  );
}

function CashFlowChart({ compact = false }) {
  const [period, setPeriod] = useState("monthly");
  return (
    <GlassCard className="p-5 sm:p-6">
      <SectionHeader
        eyebrow="Trend"
        title="Cash Flow"
        action={<SegmentedControl value={period} onChange={setPeriod} options={[
          { value: "weekly", label: "W" }, { value: "monthly", label: "M" }, { value: "yearly", label: "Y" },
        ]} />}
      />
      <div className={compact ? "h-56" : "h-72"}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={CASHFLOW_DAILY} margin={{ left: -18 }}>
            <defs>
              <linearGradient id="bal" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--accent)" stopOpacity={0.35} />
                <stop offset="100%" stopColor="var(--accent)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke="var(--border)" />
            <XAxis dataKey="d" tickLine={false} axisLine={false} tick={{ fill: "var(--textMuted)", fontSize: 11 }} interval={4} />
            <YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--textMuted)", fontSize: 11 }} tickFormatter={fmtCompact} width={40} />
            <Tooltip content={<ChartTooltip />} />
            <Area type="monotone" dataKey="balance" stroke="var(--accent)" strokeWidth={2.5} fill="url(#bal)" animationDuration={1100} />
            <Area type="monotone" dataKey="forecast" stroke="var(--accent2)" strokeWidth={2} strokeDasharray="5 5" fill="transparent" animationDuration={1100} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </GlassCard>
  );
}

function SpendingDonut({ transactions }) {
  const [expanded, setExpanded] = useState(false);
  const data = useMemo(() => {
    const totals = {};
    transactions.filter((t) => t.type === "expense").forEach((t) => {
      totals[t.category] = (totals[t.category] || 0) + Math.abs(t.amount);
    });
    return Object.entries(totals).map(([cat, val]) => ({ cat, val })).sort((a, b) => b.val - a.val);
  }, [transactions]);
  const total = data.reduce((s, d) => s + d.val, 0);
  const colors = { emerald: THEMES.dark.emerald, rose: THEMES.dark.rose, amber: THEMES.dark.amber, accent: THEMES.dark.accent, accent2: THEMES.dark.accent2, slate: THEMES.dark.slate };
  return (
    <GlassCard className="p-5 sm:p-6">
      <SectionHeader eyebrow="Breakdown" title="Spending Categories" />
      <div className="flex items-center gap-6">
        <div className="w-32 h-32 shrink-0 relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={data} dataKey="val" nameKey="cat" innerRadius={42} outerRadius={62} paddingAngle={3} animationDuration={900}>
                {data.map((d, i) => (
                  <Cell key={i} fill={`var(--${CATEGORIES[d.cat]?.color || "slate"})`} stroke="none" />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 grid place-items-center pointer-events-none">
            <div className="text-center">
              <div className="text-[15px] font-semibold tabular-nums" style={{ color: "var(--text)" }}>{fmtCompact(total)}</div>
              <div className="text-[10px]" style={{ color: "var(--textFaint)" }}>total</div>
            </div>
          </div>
        </div>
        <div className="flex-1 space-y-2.5 min-w-0">
          {data.slice(0, expanded ? data.length : 4).map((d) => {
            const meta = CATEGORIES[d.cat];
            const pct = ((d.val / total) * 100).toFixed(0);
            return (
              <div key={d.cat} className="flex items-center gap-2 text-[13px]">
                <span className="w-2 h-2 rounded-full shrink-0" style={{ background: `var(--${meta.color})` }} />
                <span className="flex-1 truncate" style={{ color: "var(--text)" }}>{meta.label}</span>
                <span className="tabular-nums font-medium" style={{ color: "var(--textMuted)" }}>{pct}%</span>
              </div>
            );
          })}
          <button onClick={() => setExpanded((e) => !e)} className="text-[12px] font-medium flex items-center gap-1 pt-1" style={{ color: "var(--accent)" }}>
            {expanded ? "Show less" : "Show all"} <ChevronDown size={13} className={cx("transition-transform", expanded && "rotate-180")} />
          </button>
        </div>
      </div>
    </GlassCard>
  );
}

function InsightsRow() {
  return (
    <div className="grid sm:grid-cols-3 gap-4">
      {INSIGHTS.map((ins, i) => (
        <GlassCard key={i} className="p-4 flex items-start gap-3">
          <div className="w-8 h-8 rounded-full grid place-items-center shrink-0" style={{ background: `color-mix(in srgb, var(--${ins.tone}) 18%, transparent)` }}>
            <ins.icon size={15} style={{ color: `var(--${ins.tone})` }} />
          </div>
          <p className="text-[13px] leading-snug pt-1" style={{ color: "var(--text)" }}>{ins.text}</p>
        </GlassCard>
      ))}
    </div>
  );
}

function RecentTransactionsCard({ transactions, onSeeAll }) {
  return (
    <GlassCard className="p-5 sm:p-6">
      <SectionHeader eyebrow="Activity" title="Recent Transactions" action={
        <button onClick={onSeeAll} className="text-[12.5px] font-medium flex items-center gap-1" style={{ color: "var(--accent)" }}>
          See all <ChevronRight size={14} />
        </button>
      } />
      <div className="divide-y" style={{ borderColor: "var(--border)" }}>
        {transactions.slice(0, 6).map((t) => (
          <TxRow key={t.id} t={t} />
        ))}
      </div>
    </GlassCard>
  );
}

function TxRow({ t }) {
  const meta = CATEGORIES[t.category];
  return (
    <div className="flex items-center gap-3 py-3 group cursor-pointer">
      <CategoryIcon cat={t.category} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="text-[13.5px] font-medium truncate" style={{ color: "var(--text)" }}>{t.merchant}</span>
          {t.recurring && <Repeat size={11} style={{ color: "var(--textFaint)" }} />}
        </div>
        <div className="text-[12px]" style={{ color: "var(--textMuted)" }}>{meta.label} · {fmtDate(t.date)}</div>
      </div>
      <div className={cx("text-[13.5px] font-semibold tabular-nums")} style={{ color: t.amount > 0 ? "var(--emerald)" : "var(--text)" }}>
        {t.amount > 0 ? "+" : ""}{fmt(t.amount)}
      </div>
    </div>
  );
}

function Dashboard({ theme, go, accounts, transactions, onAction }) {
  return (
    <div className="space-y-6">
      <HeroBalanceCard theme={theme} accounts={accounts} onAction={onAction} />
      <div className="grid lg:grid-cols-2 gap-6">
        <IncomeExpenseChart />
        <CashFlowChart compact />
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        <SpendingDonut transactions={transactions} />
        <RecentTransactionsCard transactions={transactions} onSeeAll={() => go("transactions")} />
      </div>
      <div>
        <SectionHeader eyebrow="For you" title="Financial Insights" />
        <InsightsRow />
      </div>
    </div>
  );
}

/* ============================== TRANSACTIONS ============================== */
function TransactionsPage({ transactions }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [openId, setOpenId] = useState(null);

  const filtered = transactions.filter((t) => {
    const matchesQuery = (t.merchant + CATEGORIES[t.category].label).toLowerCase().includes(query.toLowerCase());
    const matchesFilter = filter === "all" || t.type === filter;
    return matchesQuery && matchesFilter;
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Transactions</h1>
          <p className="text-[13px]" style={{ color: "var(--textMuted)" }}>{filtered.length} transactions this month</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "var(--textFaint)" }} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search transactions…"
              className="pl-9 pr-3 py-2 rounded-full text-[13px] w-56 outline-none border transition-all focus:w-64"
              style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text)" }}
            />
          </div>
          <button className="p-2.5 rounded-full border" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
            <SlidersHorizontal size={15} style={{ color: "var(--textMuted)" }} />
          </button>
        </div>
      </div>

      <SegmentedControl
        value={filter}
        onChange={setFilter}
        options={[
          { value: "all", label: "All" },
          { value: "income", label: "Income" },
          { value: "expense", label: "Expense" },
          { value: "transfer", label: "Transfers" },
        ]}
      />

      <GlassCard className="p-2 sm:p-3">
        {filtered.length === 0 ? (
          <EmptyState icon={Search} title="No transactions found" subtitle="Try adjusting your search or filters." />
        ) : (
          <div className="divide-y" style={{ borderColor: "var(--border)" }}>
            {filtered.map((t) => (
              <div key={t.id}>
                <div
                  onClick={() => setOpenId(openId === t.id ? null : t.id)}
                  className="flex items-center gap-3 px-3 py-3 cursor-pointer rounded-xl transition-colors hover:bg-[var(--surface3)]"
                >
                  <CategoryIcon cat={t.category} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[14px] font-medium" style={{ color: "var(--text)" }}>{t.merchant}</span>
                      {t.recurring && <Pill tone="accent2"><Repeat size={10} />Recurring</Pill>}
                      {t.tags.map((tag) => <Pill key={tag} tone="slate"><Tag size={10} />{tag}</Pill>)}
                    </div>
                    <div className="text-[12px] mt-0.5" style={{ color: "var(--textMuted)" }}>
                      {CATEGORIES[t.category].label} · {t.account} · {fmtDate(t.date)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[14px] font-semibold tabular-nums" style={{ color: t.amount > 0 ? "var(--emerald)" : "var(--text)" }}>
                      {t.amount > 0 ? "+" : ""}{fmt(t.amount)}
                    </div>
                    <div className="text-[11px] capitalize" style={{ color: "var(--textFaint)" }}>{t.type}</div>
                  </div>
                  <ChevronDown size={15} className={cx("transition-transform", openId === t.id && "rotate-180")} style={{ color: "var(--textFaint)" }} />
                </div>
                {openId === t.id && (
                  <div className="px-3 pb-4 pl-16 grid sm:grid-cols-3 gap-3 anim-fade-in">
                    <div className="text-[12.5px]"><span style={{ color: "var(--textFaint)" }}>Account </span><span style={{ color: "var(--text)" }}>{t.account}</span></div>
                    <div className="text-[12.5px]"><span style={{ color: "var(--textFaint)" }}>Notes </span><span style={{ color: "var(--text)" }}>{t.notes || "Add a note…"}</span></div>
                    <div className="text-[12.5px]"><span style={{ color: "var(--textFaint)" }}>Status </span><Pill tone="emerald"><CheckCircle2 size={10} />Cleared</Pill></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </GlassCard>
    </div>
  );
}

/* ============================== ACCOUNTS ============================== */
function AccountsPage({ accounts }) {
  const groups = accounts.reduce((acc, a) => {
    (acc[a.type] = acc[a.type] || []).push(a);
    return acc;
  }, {});
  const total = accounts.reduce((s, a) => s + a.balance, 0);
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Accounts</h1>
          <p className="text-[13px]" style={{ color: "var(--textMuted)" }}>Total balance across {accounts.length} accounts</p>
        </div>
        <div className="text-[20px] font-semibold tabular-nums" style={{ color: "var(--text)" }}>{fmt(total)}</div>
      </div>
      {Object.entries(groups).map(([type, accs]) => (
        <div key={type}>
          <div className="text-[12px] font-semibold tracking-wide uppercase mb-3" style={{ color: "var(--textFaint)" }}>{type}</div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {accs.map((a) => (
              <GlassCard key={a.id} className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl grid place-items-center" style={{ background: "var(--accentSoft)" }}>
                    <a.icon size={17} style={{ color: "var(--accent)" }} />
                  </div>
                  <span className={cx("inline-flex items-center gap-0.5 text-[12px] font-medium")} style={{ color: a.trend >= 0 ? "var(--emerald)" : "var(--rose)" }}>
                    {a.trend >= 0 ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}{Math.abs(a.trend)}%
                  </span>
                </div>
                <div className="text-[13.5px] font-medium mb-0.5" style={{ color: "var(--text)" }}>{a.name}</div>
                <div className="text-[11.5px] mb-3" style={{ color: "var(--textFaint)" }}>{a.bank}{a.last4 && ` · •••• ${a.last4}`}</div>
                <div className="text-[22px] font-semibold tabular-nums" style={{ color: a.balance < 0 ? "var(--rose)" : "var(--text)" }}>{fmt(a.balance)}</div>
              </GlassCard>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ============================== BUDGETS ============================== */
function BudgetsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Budgets</h1>
        <p className="text-[13px]" style={{ color: "var(--textMuted)" }}>Monthly · July 2026</p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {BUDGETS.map((b) => {
          const meta = CATEGORIES[b.category];
          const pct = Math.round((b.spent / b.limit) * 100);
          const over = b.spent > b.limit;
          return (
            <GlassCard key={b.id} className="p-5 flex items-center gap-4">
              <ProgressRing percent={pct} color={`var(--${meta.color})`}>
                <meta.icon size={18} style={{ color: `var(--${meta.color})` }} />
              </ProgressRing>
              <div className="flex-1 min-w-0">
                <div className="text-[14px] font-medium mb-0.5" style={{ color: "var(--text)" }}>{meta.label}</div>
                <div className="text-[12px] mb-1.5" style={{ color: over ? "var(--rose)" : "var(--textMuted)" }}>
                  {fmt(b.spent, { maximumFractionDigits: 0 })} of {fmt(b.limit, { maximumFractionDigits: 0 })}
                </div>
                {over ? (
                  <Pill tone="rose"><AlertTriangle size={10} />Over budget</Pill>
                ) : pct > 85 ? (
                  <Pill tone="amber"><Clock size={10} />Almost there</Pill>
                ) : (
                  <Pill tone="emerald"><CheckCircle2 size={10} />On track</Pill>
                )}
              </div>
            </GlassCard>
          );
        })}
      </div>
    </div>
  );
}

/* ============================== GOALS ============================== */
function GoalsPage({ goals, onNewGoal }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Savings Goals</h1>
          <p className="text-[13px]" style={{ color: "var(--textMuted)" }}>{goals.length} active goals</p>
        </div>
        <button
          onClick={onNewGoal}
          className="flex items-center gap-1.5 text-[12.5px] font-medium rounded-full px-3.5 py-2 text-white transition-transform active:scale-[0.97]"
          style={{ background: "linear-gradient(135deg, var(--accent), var(--accent2))" }}
        >
          <Plus size={14} /> New Goal
        </button>
      </div>
      <div className="grid sm:grid-cols-2 gap-5">
        {goals.map((g) => {
          const pct = Math.min(100, Math.round((g.current / g.target) * 100));
          const complete = g.current >= g.target;
          return (
            <GlassCard key={g.id} className="p-6 relative overflow-hidden">
              {complete && <div className="absolute top-3 right-3"><Pill tone="emerald"><Sparkles size={10} />Goal reached!</Pill></div>}
              <div className="flex items-center gap-3 mb-5">
                <div className="w-11 h-11 rounded-2xl grid place-items-center" style={{ background: `color-mix(in srgb, var(--${g.color}) 18%, transparent)` }}>
                  <g.icon size={19} style={{ color: `var(--${g.color})` }} />
                </div>
                <div>
                  <div className="text-[15px] font-semibold" style={{ color: "var(--text)" }}>{g.name}</div>
                  <div className="text-[12px]" style={{ color: "var(--textMuted)" }}>Target {fmtDate(g.due)}</div>
                </div>
              </div>
              <div className="flex items-baseline justify-between mb-2">
                <span className="text-[20px] font-semibold tabular-nums" style={{ color: "var(--text)" }}>{fmt(g.current, { maximumFractionDigits: 0 })}</span>
                <span className="text-[12.5px]" style={{ color: "var(--textMuted)" }}>of {fmt(g.target, { maximumFractionDigits: 0 })}</span>
              </div>
              <div className="h-2.5 rounded-full overflow-hidden" style={{ background: "var(--surface3)" }}>
                <div className="h-full rounded-full goal-bar" style={{ width: `${pct}%`, background: `linear-gradient(90deg, var(--${g.color}), var(--accent2))` }} />
              </div>
              <div className="flex items-center justify-between mt-2 text-[12px]" style={{ color: "var(--textFaint)" }}>
                <span>{pct}% funded</span>
                <span>{fmt(g.target - g.current, { maximumFractionDigits: 0 })} left</span>
              </div>
            </GlassCard>
          );
        })}
      </div>
    </div>
  );
}

/* ============================== ANALYTICS ============================== */
function AnalyticsPage({ accounts, transactions }) {
  const savingsRate = 31;
  const netWorth = accounts.reduce((s, a) => s + a.balance, 0);
  const stats = [
    { label: "Savings Rate", value: `${savingsRate}%`, delta: "+4.2%", tone: "emerald" },
    { label: "Net Worth", value: fmt(netWorth, { maximumFractionDigits: 0 }), delta: "+8.1%", tone: "emerald" },
    { label: "Budget Adherence", value: "84%", delta: "-2.1%", tone: "rose" },
    { label: "Avg. Daily Spend", value: fmt(118), delta: "-6.4%", tone: "emerald" },
  ];
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Analytics</h1>
        <p className="text-[13px]" style={{ color: "var(--textMuted)" }}>Your financial performance, unpacked</p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <GlassCard key={s.label} className="p-5">
            <div className="text-[12px] mb-2" style={{ color: "var(--textFaint)" }}>{s.label}</div>
            <div className="text-[21px] font-semibold tabular-nums mb-1.5" style={{ color: "var(--text)" }}>{s.value}</div>
            <Pill tone={s.tone}>{s.delta} vs last month</Pill>
          </GlassCard>
        ))}
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        <IncomeExpenseChart />
        <SpendingDonut transactions={transactions} />
      </div>
      <CashFlowChart />
    </div>
  );
}

/* ============================== SUBSCRIPTIONS ============================== */
function SubscriptionsPage() {
  const total = SUBSCRIPTIONS.reduce((s, x) => s + x.price, 0);
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Subscriptions</h1>
          <p className="text-[13px]" style={{ color: "var(--textMuted)" }}>{SUBSCRIPTIONS.length} active subscriptions detected</p>
        </div>
        <GlassCard className="px-4 py-2.5">
          <span className="text-[12px]" style={{ color: "var(--textFaint)" }}>Monthly total </span>
          <span className="text-[15px] font-semibold tabular-nums" style={{ color: "var(--text)" }}>{fmt(total)}</span>
        </GlassCard>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {SUBSCRIPTIONS.map((s) => (
          <GlassCard key={s.id} className="p-5 flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl grid place-items-center" style={{ background: `color-mix(in srgb, var(--${s.color}) 18%, transparent)` }}>
              <s.icon size={18} style={{ color: `var(--${s.color})` }} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[14px] font-medium" style={{ color: "var(--text)" }}>{s.name}</div>
              <div className="text-[12px]" style={{ color: "var(--textMuted)" }}>Renews {fmtDate(s.next)}</div>
            </div>
            <div className="text-[14px] font-semibold tabular-nums" style={{ color: "var(--text)" }}>{fmt(s.price)}</div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

/* ============================== BILLS ============================== */
function BillsPage({ bills, onPay }) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Bills</h1>
        <p className="text-[13px]" style={{ color: "var(--textMuted)" }}>Upcoming and recent payments</p>
      </div>
      <GlassCard className="p-2 sm:p-3">
        <div className="divide-y" style={{ borderColor: "var(--border)" }}>
          {bills.map((b) => (
            <div key={b.id} className="flex items-center gap-3 px-3 py-3.5">
              <div className="w-10 h-10 rounded-xl grid place-items-center" style={{ background: "var(--accentSoft)" }}>
                <Receipt size={16} style={{ color: "var(--accent)" }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[14px] font-medium" style={{ color: "var(--text)" }}>{b.name}</div>
                <div className="text-[12px]" style={{ color: "var(--textMuted)" }}>Due {fmtDate(b.due)} · {b.autopay ? "Autopay on" : "Autopay off"}</div>
              </div>
              <div className="text-[14px] font-semibold tabular-nums" style={{ color: "var(--text)" }}>{fmt(b.amount)}</div>
              {b.status === "paid" ? (
                <Pill tone="emerald"><CheckCircle2 size={10} />Paid</Pill>
              ) : (
                <>
                  <Pill tone="amber"><Clock size={10} />Upcoming</Pill>
                  <button
                    onClick={() => onPay(b)}
                    className="text-[12px] font-medium rounded-full px-3 py-1.5 transition-colors"
                    style={{ background: "var(--accentSoft)", color: "var(--accent)" }}
                  >
                    Pay now
                  </button>
                </>
              )}
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}

/* ============================== SETTINGS ============================== */
function SettingsPage({ theme, setTheme, reducedMotion, setReducedMotion }) {
  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Settings</h1>
        <p className="text-[13px]" style={{ color: "var(--textMuted)" }}>Appearance and accessibility</p>
      </div>
      <GlassCard className="p-6">
        <SectionHeader eyebrow="Appearance" title="Theme" />
        <div className="grid grid-cols-3 gap-3">
          {["dark", "light", "neutral"].map((t) => (
            <button
              key={t}
              onClick={() => setTheme(t)}
              className="rounded-2xl p-3 border text-left transition-all"
              style={{ borderColor: theme === t ? "var(--accent)" : "var(--border)", background: "var(--surface2)", boxShadow: theme === t ? "0 0 0 2px var(--accentSoft)" : "none" }}
            >
              <div className="h-12 rounded-lg mb-2" style={{ background: `linear-gradient(135deg, ${THEMES[t].heroFrom}, ${THEMES[t].heroTo})` }} />
              <div className="text-[12.5px] font-medium capitalize" style={{ color: "var(--text)" }}>{t}</div>
            </button>
          ))}
        </div>
      </GlassCard>
      <GlassCard className="p-6">
        <SectionHeader eyebrow="Accessibility" title="Motion & Contrast" />
        <div className="flex items-center justify-between py-2">
          <div>
            <div className="text-[13.5px] font-medium" style={{ color: "var(--text)" }}>Reduce motion</div>
            <div className="text-[12px]" style={{ color: "var(--textMuted)" }}>Minimize animations across the app</div>
          </div>
          <button
            onClick={() => setReducedMotion((r) => !r)}
            className="w-11 h-6 rounded-full relative transition-colors"
            style={{ background: reducedMotion ? "var(--accent)" : "var(--surface3)" }}
          >
            <span className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all" style={{ left: reducedMotion ? 22 : 2 }} />
          </button>
        </div>
      </GlassCard>
    </div>
  );
}

/* ============================== COMING SOON ============================== */
function ComingSoonPage({ label, icon: Icon }) {
  return (
    <div className="space-y-6">
      <h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>{label}</h1>
      <GlassCard>
        <EmptyState icon={Icon} title={`${label} is being crafted`} subtitle="This section is scaffolded and ready — full detail views are next on the roadmap." />
      </GlassCard>
    </div>
  );
}

/* ============================== COMMAND PALETTE ============================== */
function CommandPalette({ open, onClose, go }) {
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);
  const inputRef = useRef(null);
  useEffect(() => { if (open) { setQ(""); setIdx(0); setTimeout(() => inputRef.current?.focus(), 30); } }, [open]);

  const results = useMemo(() => {
    const items = NAV.map((n) => ({ ...n, kind: "page" }));
    if (!q) return items;
    return items.filter((i) => i.label.toLowerCase().includes(q.toLowerCase()));
  }, [q]);

  const onKey = useCallback((e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setIdx((i) => Math.min(i + 1, results.length - 1)); }
    if (e.key === "ArrowUp") { e.preventDefault(); setIdx((i) => Math.max(i - 1, 0)); }
    if (e.key === "Enter" && results[idx]) { go(results[idx].id); onClose(); }
    if (e.key === "Escape") onClose();
  }, [results, idx, go, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[12vh] px-4 anim-fade-in" style={{ background: "rgba(6,7,14,0.5)" }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="w-full max-w-lg rounded-2xl border overflow-hidden anim-pop" style={{ background: "var(--surface)", borderColor: "var(--borderStrong)", boxShadow: "0 30px 80px -20px rgba(0,0,0,0.5)" }}>
        <div className="flex items-center gap-2.5 px-4 py-3.5 border-b" style={{ borderColor: "var(--border)" }}>
          <Search size={16} style={{ color: "var(--textFaint)" }} />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => { setQ(e.target.value); setIdx(0); }}
            onKeyDown={onKey}
            placeholder="Search pages, actions, or try “Food over $50”…"
            className="flex-1 bg-transparent outline-none text-[14px]"
            style={{ color: "var(--text)" }}
          />
          <kbd className="text-[10px] px-1.5 py-0.5 rounded border" style={{ color: "var(--textFaint)", borderColor: "var(--border)" }}>ESC</kbd>
        </div>
        <div className="max-h-80 overflow-y-auto p-2">
          {results.length === 0 && <div className="py-8 text-center text-[13px]" style={{ color: "var(--textMuted)" }}>No results for “{q}”</div>}
          {results.map((r, i) => (
            <button
              key={r.id}
              onClick={() => { go(r.id); onClose(); }}
              onMouseEnter={() => setIdx(i)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors"
              style={{ background: idx === i ? "var(--accentSoft)" : "transparent" }}
            >
              <r.icon size={15} style={{ color: idx === i ? "var(--accent)" : "var(--textMuted)" }} />
              <span className="text-[13.5px] flex-1" style={{ color: "var(--text)" }}>{r.label}</span>
              <ChevronRight size={13} style={{ color: "var(--textFaint)" }} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================== MODAL SHELL ============================== */
function Modal({ open, onClose, title, subtitle, children, wide = false }) {
  useEffect(() => {
    if (!open) return;
    function onKey(e) { if (e.key === "Escape") onClose(); }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 anim-fade-in" style={{ background: "rgba(6,7,14,0.55)" }} onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className={cx("w-full rounded-2xl border overflow-hidden anim-pop max-h-[88vh] flex flex-col", wide ? "max-w-lg" : "max-w-md")}
        style={{ background: "var(--surface)", borderColor: "var(--borderStrong)", boxShadow: "0 30px 80px -20px rgba(0,0,0,0.5)" }}
      >
        <div className="flex items-start justify-between px-5 py-4 border-b shrink-0" style={{ borderColor: "var(--border)" }}>
          <div>
            <div className="text-[15.5px] font-semibold" style={{ color: "var(--text)" }}>{title}</div>
            {subtitle && <div className="text-[12.5px] mt-0.5" style={{ color: "var(--textMuted)" }}>{subtitle}</div>}
          </div>
          <button onClick={onClose} className="p-1.5 rounded-full -mt-1 -mr-1" style={{ color: "var(--textFaint)" }}>
            <X size={17} />
          </button>
        </div>
        <div className="px-5 py-4 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="mb-4">
      <label className="block text-[12px] font-medium mb-1.5" style={{ color: "var(--textMuted)" }}>{label}</label>
      {children}
    </div>
  );
}

const inputStyle = { background: "var(--surface2)", borderColor: "var(--border)", color: "var(--text)" };
const inputClass = "w-full rounded-xl border px-3 py-2.5 text-[13.5px] outline-none transition-colors focus:border-[var(--accent)]";

function SubmitButton({ children, disabled }) {
  return (
    <button
      type="submit"
      disabled={disabled}
      className="w-full mt-2 rounded-xl py-2.5 text-[13.5px] font-semibold text-white transition-all active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed"
      style={{ background: "linear-gradient(135deg, var(--accent), var(--accent2))" }}
    >
      {children}
    </button>
  );
}

/* ---- Add Transaction ---- */
function AddTransactionModal({ open, onClose, accounts, onSubmit }) {
  const [type, setType] = useState("expense");
  const [merchant, setMerchant] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("groceries");
  const [accountId, setAccountId] = useState(accounts[0]?.id || "");

  useEffect(() => {
    if (open) { setType("expense"); setMerchant(""); setAmount(""); setCategory("groceries"); setAccountId(accounts[0]?.id || ""); }
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const valid = merchant.trim() && parseFloat(amount) > 0 && accountId;

  function handleSubmit(e) {
    e.preventDefault();
    if (!valid) return;
    const signed = type === "income" ? Math.abs(+amount) : -Math.abs(+amount);
    onSubmit({
      id: nextTxId++,
      merchant: merchant.trim(),
      category: type === "income" ? "income" : category,
      amount: signed,
      date: new Date().toISOString(),
      account: accounts.find((a) => a.id === accountId)?.name || "",
      accountId,
      type,
      recurring: false,
      notes: "",
      tags: [],
    });
  }

  return (
    <Modal open={open} onClose={onClose} title="Add Transaction" subtitle="Log a new expense or income entry">
      <form onSubmit={handleSubmit}>
        <Field label="Type">
          <SegmentedControl value={type} onChange={setType} options={[{ value: "expense", label: "Expense" }, { value: "income", label: "Income" }]} />
        </Field>
        <Field label="Merchant / Description">
          <input className={inputClass} style={inputStyle} value={merchant} onChange={(e) => setMerchant(e.target.value)} placeholder="e.g. Whole Foods" autoFocus />
        </Field>
        <Field label="Amount">
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[13.5px]" style={{ color: "var(--textFaint)" }}>$</span>
            <input className={inputClass} style={{ ...inputStyle, paddingLeft: 22 }} type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" />
          </div>
        </Field>
        {type === "expense" && (
          <Field label="Category">
            <select className={inputClass} style={inputStyle} value={category} onChange={(e) => setCategory(e.target.value)}>
              {Object.entries(CATEGORIES).filter(([k]) => !["income", "transfer"].includes(k)).map(([k, v]) => (
                <option key={k} value={k}>{v.label}</option>
              ))}
            </select>
          </Field>
        )}
        <Field label="Account">
          <select className={inputClass} style={inputStyle} value={accountId} onChange={(e) => setAccountId(e.target.value)}>
            {accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </Field>
        <SubmitButton disabled={!valid}>Add {type === "income" ? "Income" : "Expense"}</SubmitButton>
      </form>
    </Modal>
  );
}

/* ---- Transfer ---- */
function TransferModal({ open, onClose, accounts, onSubmit }) {
  const [fromId, setFromId] = useState(accounts[0]?.id || "");
  const [toId, setToId] = useState(accounts[1]?.id || "");
  const [amount, setAmount] = useState("");

  useEffect(() => {
    if (open) { setFromId(accounts[0]?.id || ""); setToId(accounts[1]?.id || ""); setAmount(""); }
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const valid = fromId && toId && fromId !== toId && parseFloat(amount) > 0;

  function handleSubmit(e) {
    e.preventDefault();
    if (!valid) return;
    onSubmit({ fromId, toId, amount: +amount });
  }

  return (
    <Modal open={open} onClose={onClose} title="Transfer Money" subtitle="Move funds between your accounts">
      <form onSubmit={handleSubmit}>
        <Field label="From">
          <select className={inputClass} style={inputStyle} value={fromId} onChange={(e) => setFromId(e.target.value)}>
            {accounts.map((a) => <option key={a.id} value={a.id}>{a.name} · {fmt(a.balance)}</option>)}
          </select>
        </Field>
        <div className="flex justify-center -my-1.5"><div className="w-7 h-7 rounded-full grid place-items-center" style={{ background: "var(--accentSoft)" }}><ArrowLeftRight size={13} style={{ color: "var(--accent)" }} /></div></div>
        <Field label="To">
          <select className={inputClass} style={inputStyle} value={toId} onChange={(e) => setToId(e.target.value)}>
            {accounts.filter((a) => a.id !== fromId).map((a) => <option key={a.id} value={a.id}>{a.name} · {fmt(a.balance)}</option>)}
          </select>
        </Field>
        <Field label="Amount">
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[13.5px]" style={{ color: "var(--textFaint)" }}>$</span>
            <input className={inputClass} style={{ ...inputStyle, paddingLeft: 22 }} type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" autoFocus />
          </div>
        </Field>
        {fromId === toId && <div className="text-[12px] mb-2" style={{ color: "var(--rose)" }}>Choose two different accounts.</div>}
        <SubmitButton disabled={!valid}>Transfer</SubmitButton>
      </form>
    </Modal>
  );
}

/* ---- Pay a Bill ---- */
function PayBillModal({ open, onClose, bills, accounts, presetBillId, onSubmit }) {
  const unpaid = bills.filter((b) => b.status !== "paid");
  const [billId, setBillId] = useState(presetBillId ?? unpaid[0]?.id ?? null);
  const [accountId, setAccountId] = useState(accounts[0]?.id || "");

  useEffect(() => {
    if (open) { setBillId(presetBillId ?? unpaid[0]?.id ?? null); setAccountId(accounts[0]?.id || ""); }
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const bill = unpaid.find((b) => b.id === billId);
  const valid = bill && accountId;

  function handleSubmit(e) {
    e.preventDefault();
    if (!valid) return;
    onSubmit({ billId, accountId });
  }

  if (unpaid.length === 0) {
    return (
      <Modal open={open} onClose={onClose} title="Pay a Bill">
        <EmptyState icon={CheckCircle2} title="All caught up" subtitle="You have no unpaid bills right now." />
      </Modal>
    );
  }

  return (
    <Modal open={open} onClose={onClose} title="Pay a Bill" subtitle="Select a bill to mark as paid">
      <form onSubmit={handleSubmit}>
        <Field label="Bill">
          <div className="space-y-2 max-h-44 overflow-y-auto pr-0.5">
            {unpaid.map((b) => (
              <label
                key={b.id}
                className="flex items-center gap-3 px-3 py-2.5 rounded-xl border cursor-pointer transition-colors"
                style={{ borderColor: billId === b.id ? "var(--accent)" : "var(--border)", background: billId === b.id ? "var(--accentSoft)" : "var(--surface2)" }}
              >
                <input type="radio" name="bill" className="accent-[var(--accent)]" checked={billId === b.id} onChange={() => setBillId(b.id)} />
                <div className="flex-1 min-w-0">
                  <div className="text-[13.5px] font-medium" style={{ color: "var(--text)" }}>{b.name}</div>
                  <div className="text-[11.5px]" style={{ color: "var(--textMuted)" }}>Due {fmtDate(b.due)}</div>
                </div>
                <div className="text-[13.5px] font-semibold tabular-nums" style={{ color: "var(--text)" }}>{fmt(b.amount)}</div>
              </label>
            ))}
          </div>
        </Field>
        <Field label="Pay from">
          <select className={inputClass} style={inputStyle} value={accountId} onChange={(e) => setAccountId(e.target.value)}>
            {accounts.map((a) => <option key={a.id} value={a.id}>{a.name} · {fmt(a.balance)}</option>)}
          </select>
        </Field>
        <SubmitButton disabled={!valid}>Pay {bill ? fmt(bill.amount) : ""}</SubmitButton>
      </form>
    </Modal>
  );
}

/* ---- New Goal ---- */
function NewGoalModal({ open, onClose, onSubmit }) {
  const [name, setName] = useState("");
  const [target, setTarget] = useState("");
  const [current, setCurrent] = useState("");
  const [due, setDue] = useState("");
  const [iconKey, setIconKey] = useState("target");
  const [color, setColor] = useState("accent");

  useEffect(() => {
    if (open) { setName(""); setTarget(""); setCurrent(""); setDue(""); setIconKey("target"); setColor("accent"); }
  }, [open]);

  const valid = name.trim() && parseFloat(target) > 0 && due;

  function handleSubmit(e) {
    e.preventDefault();
    if (!valid) return;
    onSubmit({
      id: nextGoalId++,
      name: name.trim(),
      target: +target,
      current: +current || 0,
      due,
      icon: GOAL_ICON_OPTIONS.find((o) => o.key === iconKey)?.icon || Target,
      color,
    });
  }

  return (
    <Modal open={open} onClose={onClose} title="New Savings Goal" subtitle="Set a target and track your progress">
      <form onSubmit={handleSubmit}>
        <Field label="Goal name">
          <input className={inputClass} style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Home Renovation" autoFocus />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Target amount">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[13.5px]" style={{ color: "var(--textFaint)" }}>$</span>
              <input className={inputClass} style={{ ...inputStyle, paddingLeft: 22 }} type="number" min="0" value={target} onChange={(e) => setTarget(e.target.value)} placeholder="5000" />
            </div>
          </Field>
          <Field label="Starting amount">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[13.5px]" style={{ color: "var(--textFaint)" }}>$</span>
              <input className={inputClass} style={{ ...inputStyle, paddingLeft: 22 }} type="number" min="0" value={current} onChange={(e) => setCurrent(e.target.value)} placeholder="0" />
            </div>
          </Field>
        </div>
        <Field label="Target date">
          <input className={inputClass} style={inputStyle} type="date" value={due} onChange={(e) => setDue(e.target.value)} />
        </Field>
        <Field label="Icon & color">
          <div className="flex items-center gap-2 flex-wrap">
            {GOAL_ICON_OPTIONS.map((o) => (
              <button key={o.key} type="button" onClick={() => setIconKey(o.key)}
                className="w-9 h-9 rounded-xl grid place-items-center border transition-colors"
                style={{ borderColor: iconKey === o.key ? "var(--accent)" : "var(--border)", background: iconKey === o.key ? "var(--accentSoft)" : "var(--surface2)" }}>
                <o.icon size={15} style={{ color: iconKey === o.key ? "var(--accent)" : "var(--textMuted)" }} />
              </button>
            ))}
            <div className="w-px h-6 mx-1" style={{ background: "var(--border)" }} />
            {GOAL_COLOR_OPTIONS.map((c) => (
              <button key={c} type="button" onClick={() => setColor(c)}
                className="w-7 h-7 rounded-full border-2 transition-transform"
                style={{ background: `var(--${c})`, borderColor: color === c ? "var(--text)" : "transparent", transform: color === c ? "scale(1.1)" : "scale(1)" }} />
            ))}
          </div>
        </Field>
        <SubmitButton disabled={!valid}>Create Goal</SubmitButton>
      </form>
    </Modal>
  );
}

/* ---- Toast ---- */
function Toast({ message }) {
  if (!message) return null;
  return (
    <div className="fixed bottom-6 right-6 z-[60] anim-pop">
      <div className="flex items-center gap-2.5 px-4 py-3 rounded-xl border" style={{ background: "var(--surface)", borderColor: "var(--borderStrong)", boxShadow: "0 20px 50px -16px rgba(0,0,0,0.4)" }}>
        <div className="w-6 h-6 rounded-full grid place-items-center shrink-0" style={{ background: "var(--accentSoft)" }}>
          <CheckCircle2 size={13} style={{ color: "var(--accent)" }} />
        </div>
        <span className="text-[13px] font-medium" style={{ color: "var(--text)" }}>{message}</span>
      </div>
    </div>
  );
}

/* ============================== SHELL: SIDEBAR / TOPBAR ============================== */
function Sidebar({ page, go, collapsed, setCollapsed, mobileOpen, setMobileOpen }) {
  const content = (
    <div className="h-full flex flex-col">
      <div className={cx("flex items-center gap-2.5 px-4 h-16 shrink-0", collapsed && "justify-center px-0")}>
        <div className="w-8 h-8 rounded-xl grid place-items-center shrink-0" style={{ background: "linear-gradient(135deg, var(--accent), var(--accent2))" }}>
          <Wallet size={16} className="text-white" />
        </div>
        {!collapsed && <span className="text-[15px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Ledger</span>}
      </div>
      <nav className="flex-1 overflow-y-auto px-2.5 py-2 space-y-0.5">
        {NAV.map((n) => {
          const active = page === n.id;
          return (
            <button
              key={n.id}
              onClick={() => { go(n.id); setMobileOpen(false); }}
              className={cx("w-full flex items-center gap-3 px-2.5 py-2.5 rounded-xl text-[13.5px] font-medium transition-all duration-200 relative", collapsed && "justify-center px-0")}
              style={{ color: active ? "var(--accent)" : "var(--textMuted)", background: active ? "var(--accentSoft)" : "transparent" }}
              title={collapsed ? n.label : undefined}
            >
              <n.icon size={17} strokeWidth={2} />
              {!collapsed && <span className="truncate">{n.label}</span>}
            </button>
          );
        })}
      </nav>
      <div className="p-2.5">
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="hidden lg:flex w-full items-center gap-2 px-2.5 py-2.5 rounded-xl text-[12.5px] font-medium transition-colors"
          style={{ color: "var(--textFaint)" }}
        >
          <ChevronLeft size={15} className={cx("transition-transform", collapsed && "rotate-180")} />
          {!collapsed && "Collapse"}
        </button>
      </div>
    </div>
  );

  return (
    <>
      <aside
        className={cx("hidden lg:flex flex-col shrink-0 border-r transition-all duration-300", collapsed ? "w-[76px]" : "w-64")}
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        {content}
      </aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 anim-fade-in" style={{ background: "rgba(6,7,14,0.5)" }} onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-72 anim-slide-in border-r" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
            {content}
          </aside>
        </div>
      )}
    </>
  );
}

function TopBar({ page, theme, setTheme, onOpenPalette, onOpenMobile }) {
  const label = NAV.find((n) => n.id === page)?.label || "Dashboard";
  return (
    <header className="sticky top-0 z-30 flex items-center gap-3 px-4 sm:px-6 h-16 border-b backdrop-blur-xl" style={{ background: "color-mix(in srgb, var(--bg) 80%, transparent)", borderColor: "var(--border)" }}>
      <button className="lg:hidden p-2 -ml-2" onClick={onOpenMobile}><Menu size={19} style={{ color: "var(--text)" }} /></button>
      <h1 className="text-[15.5px] font-semibold tracking-tight hidden sm:block" style={{ color: "var(--text)" }}>{label}</h1>
      <div className="flex-1" />
      <button
        onClick={onOpenPalette}
        className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-full border text-[12.5px] transition-colors"
        style={{ borderColor: "var(--border)", background: "var(--surface)", color: "var(--textMuted)" }}
      >
        <Search size={13} /> Search <kbd className="ml-2 text-[10px] px-1.5 py-0.5 rounded border" style={{ borderColor: "var(--border)" }}>⌘K</kbd>
      </button>
      <button onClick={onOpenPalette} className="sm:hidden p-2 rounded-full" style={{ color: "var(--textMuted)" }}><Search size={17} /></button>
      <div className="flex items-center rounded-full p-1 gap-0.5" style={{ background: "var(--surface3)" }}>
        {[["dark", Moon], ["light", Sun], ["neutral", Cloud]].map(([t, Icon]) => (
          <button key={t} onClick={() => setTheme(t)} className="w-7 h-7 rounded-full grid place-items-center transition-colors" style={{ background: theme === t ? "var(--surface)" : "transparent" }}>
            <Icon size={13} style={{ color: theme === t ? "var(--accent)" : "var(--textFaint)" }} />
          </button>
        ))}
      </div>
      <button className="p-2 rounded-full relative" style={{ color: "var(--textMuted)" }}>
        <Bell size={17} />
        <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full" style={{ background: "var(--rose)" }} />
      </button>
      <div className="w-8 h-8 rounded-full grid place-items-center text-[12px] font-semibold text-white shrink-0" style={{ background: "linear-gradient(135deg, var(--accent), var(--accent2))" }}>
        JD
      </div>
    </header>
  );
}


/* ============================== PERSISTENCE ============================== */
const STORE_KEY = "ledger:v1";
const ICON_REGISTRY = { target: Target, landmark: Landmark, plane: Plane, car: Car, home: HomeIcon, star: Star };
const iconKeyOf = (Icon) => Object.keys(ICON_REGISTRY).find((k) => ICON_REGISTRY[k] === Icon) || "target";

function loadSaved() {
  try { return JSON.parse(localStorage.getItem(STORE_KEY) || "null"); } catch { return null; }
}
function usePersisted(key, initial, { dehydrate = (v) => v, hydrate = (v) => v } = {}) {
  const [value, setValue] = useState(() => {
    const saved = loadSaved();
    return saved && saved[key] !== undefined ? hydrate(saved[key]) : initial;
  });
  useEffect(() => {
    try {
      const saved = loadSaved() || {};
      saved[key] = dehydrate(value);
      localStorage.setItem(STORE_KEY, JSON.stringify(saved));
    } catch { /* storage full or unavailable */ }
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps
  return [value, setValue];
}

/* ============================== ROOT APP ============================== */
export default function App() {
  const [theme, setTheme] = usePersisted("theme", "dark");
  const [page, setPage] = useState("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [reducedMotion, setReducedMotion] = usePersisted("reducedMotion", false);

  const [accounts, setAccounts] = usePersisted("accounts", INITIAL_ACCOUNTS, {
    dehydrate: (list) => Object.fromEntries(list.map((a) => [a.id, a.balance])),
    hydrate: (map) => INITIAL_ACCOUNTS.map((a) => (map[a.id] !== undefined ? { ...a, balance: map[a.id] } : a)),
  });
  const [transactions, setTransactions] = usePersisted("transactions", INITIAL_TRANSACTIONS);
  const [goals, setGoals] = usePersisted("goals", INITIAL_GOALS, {
    dehydrate: (list) => list.map((g) => ({ ...g, icon: iconKeyOf(g.icon) })),
    hydrate: (list) => list.map((g) => ({ ...g, icon: ICON_REGISTRY[g.icon] || Target })),
  });
  const [bills, setBills] = usePersisted("bills", INITIAL_BILLS);

  useEffect(() => {
    nextTxId = Math.max(nextTxId, ...transactions.map((x) => x.id + 1));
    nextGoalId = Math.max(nextGoalId, ...goals.map((x) => x.id + 1));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const [modal, setModal] = useState(null); // 'transaction' | 'transfer' | 'bill' | 'goal' | null
  const [presetBillId, setPresetBillId] = useState(null);
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);
  const notify = useCallback((msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  }, []);

  function adjustBalance(accountId, delta) {
    setAccounts((prev) => prev.map((a) => (a.id === accountId ? { ...a, balance: +(a.balance + delta).toFixed(2) } : a)));
  }

  function handleAddTransaction(tx) {
    setTransactions((prev) => [tx, ...prev]);
    if (tx.accountId) adjustBalance(tx.accountId, tx.amount);
    setModal(null);
    notify(`${tx.type === "income" ? "Income" : "Expense"} of ${fmt(Math.abs(tx.amount))} added`);
  }

  function handleTransfer({ fromId, toId, amount }) {
    const fromAcc = accounts.find((a) => a.id === fromId);
    const toAcc = accounts.find((a) => a.id === toId);
    adjustBalance(fromId, -amount);
    adjustBalance(toId, amount);
    const now = new Date().toISOString();
    setTransactions((prev) => [
      { id: nextTxId++, merchant: `Transfer to ${toAcc?.name || ""}`, category: "transfer", amount: -amount, date: now, account: fromAcc?.name || "", accountId: fromId, type: "transfer", recurring: false, notes: "", tags: [] },
      { id: nextTxId++, merchant: `Transfer from ${fromAcc?.name || ""}`, category: "transfer", amount: amount, date: now, account: toAcc?.name || "", accountId: toId, type: "transfer", recurring: false, notes: "", tags: [] },
      ...prev,
    ]);
    setModal(null);
    notify(`Transferred ${fmt(amount)} to ${toAcc?.name || "account"}`);
  }

  function handlePayBill({ billId, accountId }) {
    const bill = bills.find((b) => b.id === billId);
    if (!bill) return;
    const acc = accounts.find((a) => a.id === accountId);
    setBills((prev) => prev.map((b) => (b.id === billId ? { ...b, status: "paid" } : b)));
    adjustBalance(accountId, -bill.amount);
    setTransactions((prev) => [
      { id: nextTxId++, merchant: bill.name, category: "utilities", amount: -bill.amount, date: new Date().toISOString(), account: acc?.name || "", accountId, type: "expense", recurring: false, notes: "", tags: [] },
      ...prev,
    ]);
    setModal(null);
    notify(`${bill.name} paid from ${acc?.name || "account"}`);
  }

  function handleAddGoal(goal) {
    setGoals((prev) => [...prev, goal]);
    setModal(null);
    notify(`Goal “${goal.name}” created`);
  }

  useEffect(() => {
    function onKey(e) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPaletteOpen((o) => !o); }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const t = THEMES[theme];
  const cssVars = {
    "--bg": t.bg, "--surface": t.surface, "--surface2": t.surface2, "--surface3": t.surface3,
    "--border": t.border, "--borderStrong": t.borderStrong, "--text": t.text, "--textMuted": t.textMuted, "--textFaint": t.textFaint,
    "--accent": t.accent, "--accent2": t.accent2, "--accentSoft": t.accentSoft, "--glass": t.glass, "--glassStrong": t.glassStrong,
    "--emerald": t.emerald, "--rose": t.rose, "--amber": t.amber, "--slate": t.slate, "--card-shadow": t.shadow,
  };

  const renderPage = () => {
    switch (page) {
      case "dashboard": return <Dashboard theme={theme} go={setPage} accounts={accounts} transactions={transactions} onAction={setModal} />;
      case "transactions": return <TransactionsPage transactions={transactions} />;
      case "accounts": return <AccountsPage accounts={accounts} />;
      case "budgets": return <BudgetsPage />;
      case "goals": return <GoalsPage goals={goals} onNewGoal={() => setModal("goal")} />;
      case "cashflow": return <div className="space-y-6"><h1 className="text-[22px] font-semibold tracking-tight" style={{ color: "var(--text)" }}>Cash Flow</h1><CashFlowChart /><div className="grid lg:grid-cols-2 gap-6"><IncomeExpenseChart /><InsightsRow /></div></div>;
      case "analytics": return <AnalyticsPage accounts={accounts} transactions={transactions} />;
      case "subscriptions": return <SubscriptionsPage />;
      case "bills": return <BillsPage bills={bills} onPay={(b) => { setPresetBillId(b.id); setModal("bill"); }} />;
      case "settings": return <SettingsPage theme={theme} setTheme={setTheme} reducedMotion={reducedMotion} setReducedMotion={setReducedMotion} />;
      case "investments": return <ComingSoonPage label="Investments" icon={TrendingUp} />;
      case "reports": return <ComingSoonPage label="Reports" icon={FileText} />;
      case "calendar": return <ComingSoonPage label="Calendar" icon={CalendarIcon} />;
      default: return <Dashboard theme={theme} go={setPage} accounts={accounts} transactions={transactions} onAction={setModal} />;
    }
  };

  return (
    <div style={{ ...cssVars, paddingTop: "env(safe-area-inset-top)", paddingBottom: "env(safe-area-inset-bottom)", background: "var(--bg)" }} className={cx("flex h-[100dvh] w-full overflow-hidden font-sans", reducedMotion && "reduce-motion")}>
      <style>{`
        .font-sans { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif; font-feature-settings: 'tnum' 1; }
        .tabular-nums { font-variant-numeric: tabular-nums; }
        body { background: var(--bg); }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 8px; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes popIn { from { opacity: 0; transform: scale(0.96) translateY(-4px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes slideIn { from { transform: translateX(-100%); } to { transform: translateX(0); } }
        @keyframes floatA { 0%,100% { transform: translate(0,0); } 50% { transform: translate(20px,-16px); } }
        @keyframes floatB { 0%,100% { transform: translate(0,0); } 50% { transform: translate(-24px,14px); } }
        @keyframes barGrow { from { width: 0; } }
        .anim-fade-in { animation: fadeIn 0.25s ease; }
        .anim-pop { animation: popIn 0.22s cubic-bezier(.22,1,.36,1); }
        .anim-slide-in { animation: slideIn 0.28s cubic-bezier(.22,1,.36,1); }
        .goal-bar { animation: barGrow 1.1s cubic-bezier(.22,1,.36,1); }
        .hero-shine { isolation: isolate; }
        .hero-orb { position: absolute; border-radius: 9999px; filter: blur(50px); opacity: 0.55; pointer-events: none; }
        .hero-orb-a { width: 260px; height: 260px; background: rgba(255,255,255,0.18); top: -80px; right: -40px; animation: floatA 10s ease-in-out infinite; }
        .hero-orb-b { width: 220px; height: 220px; background: rgba(139,92,246,0.35); bottom: -80px; left: 20%; animation: floatB 12s ease-in-out infinite; }
        button { cursor: pointer; }
        input:focus, button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
        .reduce-motion, .reduce-motion * { animation-duration: 0.001s !important; transition-duration: 0.001s !important; }
        section, main .space-y-6 > * { animation: fadeInUp 0.4s ease backwards; }
      `}</style>

      <Sidebar page={page} go={setPage} collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />

      <div className="flex-1 flex flex-col min-w-0" style={{ background: "var(--bg)" }}>
        <TopBar page={page} theme={theme} setTheme={setTheme} onOpenPalette={() => setPaletteOpen(true)} onOpenMobile={() => setMobileOpen(true)} />
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 py-6">
          <div className="max-w-[1400px] mx-auto">{renderPage()}</div>
        </main>
      </div>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} go={setPage} />

      <AddTransactionModal open={modal === "transaction"} onClose={() => setModal(null)} accounts={accounts} onSubmit={handleAddTransaction} />
      <TransferModal open={modal === "transfer"} onClose={() => setModal(null)} accounts={accounts} onSubmit={handleTransfer} />
      <PayBillModal open={modal === "bill"} onClose={() => { setModal(null); setPresetBillId(null); }} bills={bills} accounts={accounts} presetBillId={presetBillId} onSubmit={handlePayBill} />
      <NewGoalModal open={modal === "goal"} onClose={() => setModal(null)} onSubmit={handleAddGoal} />
      <Toast message={toast} />
    </div>
  );
}
