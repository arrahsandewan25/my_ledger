# Ledger — Web (PWA) + Android

One codebase: runs in any browser, installs as a PWA, and packages as a native Android app via Capacitor.
Data is saved on-device (localStorage) so it survives restarts and works offline.

## Run as a web app
```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in dist/
npm run preview    # serve the build (test PWA install here)
```
Deploy `dist/` to any static host (Netlify, Vercel, Cloudflare Pages, GitHub Pages — HTTPS required for PWA install).
On Android Chrome: menu → **Install app**.

## Build the Android APK
Option A — locally (needs Android Studio or JDK 17 + Android SDK):
```bash
npm install
npm run icons
npm run android:apk      # → android/app/build/outputs/apk/debug/app-debug.apk
# or: npm run android:sync && npm run android:open   (opens Android Studio → Run ▶)
```
Option B — no setup: push this folder to GitHub; the **Build Android APK** workflow
(Actions tab) produces `app-debug.apk` as a downloadable artifact.

Copy the APK to your phone and install it (allow "install unknown apps").

## Play Store release
Android Studio → Build → Generate Signed Bundle / APK → Android App Bundle (.aab).
Change `appId` in `capacitor.config.json` (and re-run `npx cap sync`) before publishing.
