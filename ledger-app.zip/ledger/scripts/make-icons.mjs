// Generates PWA + Android launcher icons from public/favicon.svg
import sharp from "sharp";
import fs from "fs";
const svg = fs.readFileSync("public/favicon.svg");
const full = (s) => sharp(svg, { density: 384 }).resize(s, s).png();
await full(192).toFile("public/pwa-192.png");
await full(512).toFile("public/pwa-512.png");
await full(180).toFile("public/apple-touch-icon.png");
// maskable: artwork inside the 80% safe zone on a solid brand background
const inner = await sharp(svg, { density: 384 }).resize(360, 360).png().toBuffer();
await sharp({ create: { width: 512, height: 512, channels: 4, background: "#6366F1" } })
  .composite([{ input: inner, gravity: "center" }]).png().toFile("public/pwa-maskable-512.png");
console.log("Icons generated.");
