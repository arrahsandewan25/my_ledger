// Writes Android launcher icons (all densities) from public/favicon.svg
import sharp from "sharp"; import fs from "fs";
const svg = fs.readFileSync("public/favicon.svg");
const sizes = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
for (const [d, s] of Object.entries(sizes)) {
  const dir = `android/app/src/main/res/mipmap-${d}`;
  for (const n of ["ic_launcher.png", "ic_launcher_round.png"])
    await sharp(svg, { density: 384 }).resize(s, s).png().toFile(`${dir}/${n}`);
  const fg = Math.round(s * 108 / 48);
  const inner = await sharp(svg, { density: 384 }).resize(Math.round(fg * 0.6)).png().toBuffer();
  await sharp({ create: { width: fg, height: fg, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } })
    .composite([{ input: inner, gravity: "center" }]).png().toFile(`${dir}/ic_launcher_foreground.png`);
}
console.log("Android icons written.");
